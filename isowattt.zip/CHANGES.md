# Product Rebranding — Changelog

## Naming Updates

### Product Tiers
- **IsoPoint** (12Ah) — DC only, entry tier ✓
- **IsoPoint+** (12Ah + AC) — Mid tier with optional 400W AC module ✓  
- **IsoFortress** (100Ah) — Full power tier ✓

---

## Files Modified

### 1. **index.html** (Home Page)
- Updated product card names:
  - `IsoBase` → `IsoPoint+` (Mid Tier card)
  - `IsoWatt` → `IsoFortress` (Full Power card)
- Updated CTA band copy (generic "power station" reference)

### 2. **configurator.html** (Configuration Tool)
- **Product Button SKUs:**
  - `GRIDNODE 12` → `IsoPoint`
  - `GRIDNODE 12+` → `IsoPoint+`
  - `GRIDNODE 100` → `IsoFortress`

- **3D Box Face Label:** Updated to dynamic product names

- **JavaScript PRODUCTS Object:**
  ```javascript
  gn12: {
    name: 'IsoPoint',
    nameHTML: 'Iso<em>Point</em>'
  }
  gn12p: {
    name: 'IsoPoint+',
    nameHTML: 'Iso<em>Point+</em>'
  }
  gn100: {
    name: 'IsoFortress',
    nameHTML: 'Iso<em>Fortress</em>'
  }
  ```

- **Modal & Quote Panel:** Updated SKU display references
- **Runtime Section:** Updated generic copy ("your power station")

### 3. **contact.html** (Contact & FAQ)
- **Contact Form Dropdown:**
  - `IsoBase` → `IsoPoint+`
  - `IsoWatt` → `IsoFortress`

- **FAQ Section:**
  - Q: "What's the difference between IsoPoint, IsoBase, and IsoWatt?"
    - Updated to: "IsoPoint, IsoPoint+, and IsoFortress"
  - A: Updated product descriptions to use new names
  - Shipping FAQ: Updated IsoWatt references to IsoFortress

### 4. **site.js** (Navigation & Footer)
- **Footer Product Links:**
  - `IsoBase — 12Ah + AC` → `IsoPoint+ — 12Ah + AC`
  - `IsoWatt — 100Ah` → `IsoFortress — 100Ah`

### 5. **about.html**
- No product name changes required (references "IsoWatt" as brand, not product model)

### 6. **style.css**
- No changes needed (no product names in CSS)

---

## Summary of Replacements

| Old Name | New Name | Location(s) |
|----------|----------|-------------|
| GRIDNODE 12 | IsoPoint | configurator.html (JS object, buttons) |
| GRIDNODE 12+ | IsoPoint+ | configurator.html (JS object, buttons) |
| GRIDNODE 100 | IsoFortress | configurator.html (JS object, buttons, modal) |
| IsoBase | IsoPoint+ | index.html, contact.html, site.js |
| IsoWatt (product) | IsoFortress | index.html, contact.html, site.js |

**Note:** "IsoWatt" brand references remain unchanged (company name, page titles, footers, etc.)

---

## Testing Checklist

- [ ] Index homepage displays correct product cards
- [ ] Configurator product buttons select correct products
- [ ] 3D box updates with product names
- [ ] Quote panel displays correct SKU names
- [ ] Modal reservation form shows correct names
- [ ] Contact form dropdown lists updated products
- [ ] FAQ questions and answers reference correct names
- [ ] Footer links display correct product names
